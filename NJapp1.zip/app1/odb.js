const orientdb = require('orientjs');

var OrientDB = function(server) { 
	this.server = server; 
	this.odb = orientdb(this.server);
};

OrientDB.prototype.getDatabases = function() {
	
	var server = orientdb(this.server);
	
	return new Promise(function (resolve, reject) {
        var dbs = server.list().then(
			function(list){
				var names = list.map(function(db) { return db.name; });
				server.close();
				resolve(names);
			}
		).catch(
			function(err) {
				reject(err);
			}
		)	
    });	
};

OrientDB.prototype.getClasses = function(database) {
	
	var server = orientdb(this.server);
	var db = server.use(database);
	
	return new Promise(function (resolve, reject) {
        db.class.list().then(
			function(list){
				var names = list.map(function(dbclass) { return dbclass.name; });
				server.close();
				resolve(names);
			}
		).catch(
			function(err) {
				reject(err);
			}
		)	
    });
};

OrientDB.prototype.getItems = function(database, clname) {
	
	var server = orientdb(this.server);
	var db = server.use(database);
	
	return new Promise(function (resolve, reject) {
        db.class.get(clname).then(
			function(clret){
				clret.list().then(
					function(items) {
						server.close();
						resolve(items);
					}
				).catch(
					function(err1) {
						reject(err1);
					}
				)
			}
		).catch(
			function(err) {
				reject(err);
			}
		)	
    });
};

OrientDB.prototype.getQuery = function(database, sql) {
	
	var server = orientdb(this.server);
	var db = server.use(database);
	
	return new Promise(function (resolve, reject) {
        db.query(sql).then(
			function(qryret){
				server.close();
				resolve(qryret);
			}
		).catch(
			function(err) {
				reject(err);
			}
		)	
    });
};

module.exports = OrientDB;
