var config = {};

config.orientdb = { host: 'localhost', port: 2424, username: 'root', password: 'pass@word99' };
config.auth_users = ['NingZhu-PC\\NingZhu'];
config.cors_origins = ['localhost'];

module.exports = config;