const express = require('express');
const cjson = require('circular-json');
const odb = require('./odb.js');
const config = require('./config.js');
  
const dbapp = express();
const server = config.orientdb;
const odbinst = new odb(server);

dbapp.get('/', function(req, res) {
	odbinst.getDatabases().then(
		function(names){
			res.type('json').send(cjson.stringify(names));
		}
	).catch(
		function(err) {
			res.status(500).send(err);
		}
	);
});

dbapp.get('/:dbname/classes', function(req, res) {
	var dbname = req.params.dbname;
	odbinst.getClasses(dbname).then(
		function(names){
			res.type('json').send(cjson.stringify(names));
		}
	).catch(
		function(err) {
			res.status(500).send(err);
		}
	);
});

dbapp.get('/:dbname/:clname/items', function(req, res) {
	var dbname = req.params.dbname;
	var clname = req.params.clname;
	
	odbinst.getItems(dbname, clname).then(
		function(items){
			res.type('json').send(cjson.stringify(items));
		}
	).catch(
		function(err) {
			res.status(500).send(err);
		}
	);
});

dbapp.get('/:dbname/query', function(req, res) {
	var dbname = req.params.dbname;
	var sql = req.query.sql;
	
	odbinst.getQuery(dbname, sql).then(
		function(qryret){
			res.type('json').send(cjson.stringify(qryret));
		}
	).catch(
		function(err) {
			res.status(500).send(err);
		}
	);
});

dbapp.get('/:dbname/:functname/:params?', function(req, res) {
	var dbname = req.params.dbname;
	var functname = req.params.functname;
	var params = req.params;
	res.type('json').send(cjson.stringify(params));
});

module.exports = dbapp;
