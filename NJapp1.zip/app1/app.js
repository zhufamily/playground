const express = require('express');
const cjson = require('circular-json');
const sspi = require('node-sspi');
const config = require('./config.js');
const dbapp = require('./dbapp.js');
  
const app = express();
const auth_users = config.auth_users;
const cors_origins = config.cors_origins;

/*
	Windows Integrated Authentication, using both Negotiate and NTLM
	Not pulling AD group information, assuming that authorization in the express app
*/
app.use(function (req, res, next) {
	var sspiinst = new sspi({sspiPackagesUsed: ['Negotiate','NTLM']});
	sspiinst.authenticate(req, res, function(err){
		res.finished || next();
	});
});

/*
	Authorization filter -- just based on config file for now
	Further development needed -- can be easili move to database
*/
app.use(function (req, res, next) {
	if (typeof req.connection.user == 'undefined') {
		res.status(401).send('Anonymous access is not allowed!');
	} else if (auth_users.indexOf(req.connection.user) <= -1) {
		res.status(403).send(req.connection.user + ' does not have access!');
	} else {
		next();
	}
});

/*
	CORS headers 
*/
app.use(function (req, res, next) {
	var origin = req.get('Origin');
	if (typeof origin != 'undefined') {
		console.log('Current origin is: ' + origin);
		for(let item of cors_origins) {
			var re = new RegExp(item);
			if (origin.match(re) != null) {
				res.set('Access-Control-Allow-Origin', origin);
				res.set('Access-Control-Allow-Methods', 'OPTIONS,GET,POST,HEAD');
				res.set('Access-Control-Allow-Headers', 'Content-Type,Accept,Authorization,X-Requested-With');
				res.set('Access-Control-Allow-Credentials', 'true');
				break;
			}
		}
	}
	next();
});
 
 /*
	Mount orientdb sub app
 */
app.use('/db', dbapp);

app.get('/', function(req, res) {
	var parent = { pid: 1, name: 'parent'};
	parent.children = [];
	var child = { cid: 1, name: 'child', parent: parent};
	parent.children.push(child);
	res.type('json').send(cjson.stringify(parent));
});

app.listen(3000, function() {
	console.log('App1 is listening on port 3000 ...');
});
