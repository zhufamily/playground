import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { OrientComponent }   from './orient.component';
import { ClassComponent }   from './class.component';

const routes: Routes = [
  { path: 'database',  component: OrientComponent },
  { path: 'class/:database',  component: ClassComponent },
  { path: '', redirectTo: '/database', pathMatch: 'full' }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
