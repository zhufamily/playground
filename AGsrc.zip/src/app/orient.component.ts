import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { OrientService } from './orient.service';

@Component({
	selector: 'my-orient',
	templateUrl: '../html/orient.component.html',
	styleUrls: [ '../css/app.component.css' ]
})

export class OrientComponent implements OnInit {
  
	databases: string[];
	selectedDatabase: string;

	constructor(
		private router: Router,
		private orientService: OrientService) { console.log('Init the orient component ...'); }

	ngOnInit(): void {
		this.getDatabases();
	}

	getDatabases(): void {
		this.orientService.getDatabases().subscribe(
			databases => this.databases = databases,
			error => console.log(error)
		);
	}
	
	onSelect(database: string): void {
		this.selectedDatabase = database;
		this.router.navigate(['/class', this.selectedDatabase]);
	}
}
