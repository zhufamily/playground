import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Location }                 from '@angular/common';

import 'rxjs/add/operator/switchMap';

import { OrientService } from './orient.service';

@Component({
	selector: 'my-class',
	templateUrl: '../html/class.component.html',
	styleUrls: [ '../css/app.component.css' ]
})

export class ClassComponent implements OnInit {
  
	database: string;
	classes: string[];
	
	constructor(
		private route: ActivatedRoute,
		private orientService: OrientService,
		private location: Location) { console.log('Init the class component ...'); }

	ngOnInit(): void {
		this.route.paramMap
			.switchMap((params: ParamMap) => 
				{
					this.database = params.get('database');	
					return this.orientService.getClasses(this.database); 
				}
			)
			.subscribe(
				classes => this.classes = classes,
				error => console.log(error)
			); 
	}

	getClasses(): void {
		this.orientService.getClasses(this.database).subscribe(
			classes => this.classes = classes,
			error => console.log(error)
		);
	}
	
	goBack(): void {
		this.location.back();
	}
}
