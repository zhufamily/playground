import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }    from '@angular/forms';
import { HttpModule } 	  from '@angular/http';

import { AppComponent } from './app.component';
import { OrientComponent }   from './orient.component';
import { ClassComponent }   from './class.component';

import { AppRoutingModule }     from './app-routing.module';
import { OrientService } from './orient.service';

@NgModule({
	declarations: [
		AppComponent,
		OrientComponent,
		ClassComponent
	],
	imports: [
		BrowserModule,
		FormsModule,
		AppRoutingModule,
		HttpModule
	],
	providers: [OrientService],
	bootstrap: [
		AppComponent,
		OrientComponent,
		ClassComponent
	]
})
export class AppModule { }
