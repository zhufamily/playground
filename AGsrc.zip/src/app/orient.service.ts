import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';

@Injectable()
export class OrientService {
	
	constructor(private http: Http) { console.log('Init the orient component class ...') }
	
	getDatabases(): Observable<string[]> {
		return this.http.get('http://localhost:3000/db/', {withCredentials: true})
			.map(response => response.json() as string[])
			.catch(
				(error:any) => { 
					console.error(error.json().error); 
					return Observable.throw(error.json().error || 'Server error'); 
				}
			); 
	}
	
	getClasses(database: string): Observable<string[]> {
		var url = 'http://localhost:3000/db/' + database + '/classes/';
		return this.http.get(url, {withCredentials: true})
			.map(response => response.json() as string[])
			.catch(
				(error:any) => { 
					console.error(error.json().error); 
					return Observable.throw(error.json().error || 'Server error'); 
				}
			); 
	}
}
